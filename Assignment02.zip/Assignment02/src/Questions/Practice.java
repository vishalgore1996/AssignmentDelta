package Questions;

public class Practice {

}
